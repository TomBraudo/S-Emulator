S-Emulator

GitHub Repository: https://github.com/TomBraudo/S-Emulator

================================================================================
IMPLEMENTED BONUSES
================================================================================
- Step Back - Reverse debugging with full state restoration
- TreeTableView - Hierarchical program visualization
- Specific Expansion - Selective command expansion in tree view
- New Program Builder - Custom program creation with GUI form and XML export

================================================================================
QUOTE MECHANISM IMPLEMENTATION
================================================================================

The Quotation command enables subroutine calls within the S language. It 
executes a sub-program with given arguments and assigns the result to a variable.

Key Features:
- Syntax: v <- (ProgramName, arg1, arg2, ...)
- Cost: Sub-program cycles + 5 overhead
- Arguments: Supports both variable references and nested function calls
- Expansion: Inlines the sub-program with fresh temporaries (z-variables) and 
  labels to avoid collisions

Implementation Details:
- During execution, arguments are evaluated, the sub-program runs in isolation, 
  and the output (y) is captured
- Expansion creates preamble code to prepare input variables, inlines the 
  sub-program body with renamed variables/labels, and transfers the result back
- The command integrates seamlessly with the macro-expansion system, supporting 
  recursive quotation

================================================================================
GUI IMPLEMENTATION
================================================================================

Built with JavaFX and modular architecture across FXML components:

Main Components:
- MainController - Orchestrates program loading, execution modes (execute/debug), 
  and view toggling
- Command Display - Dual-view system: Table view (linear) and Tree view 
  (hierarchical expansion)
- Input System - Dynamic form generation based on program input variables
- Execution Panel - Mode-specific buttons (Execute vs. Debug with step 
  over/continue/step back)
- Statistics View - Real-time variable tracking with change highlighting and 
  execution history
- Program Builder - Modal form (NewCommandFormController) with validation for 
  adding commands interactively

Architecture:
- Separation of concerns: GUI layer communicates through Api facade to the 
  engine module
- CSS styling for modern UI with custom component classes
- Event-driven design with listeners for state changes and breakpoints

================================================================================
BONUS FEATURES EXPLAINED
================================================================================

Step Back
---------
Implements reverse debugging by maintaining a stack of SingleStepChanges that 
records old values (variable state, instruction pointer, cycles) before each 
step. Stepping back pops the stack and restores the previous state, enabling 
full rewind capability during debugging.

TreeTableView
-------------
Uses JavaFX TreeTableView to display programs hierarchically. Base commands 
appear as leaves, while high-level commands (like Quotation, Assignment) show 
their expansions as child nodes. Toggle between table and tree views for 
different perspectives on program structure.

Specific Expansion
------------------
Powered by MixedExpansionSession, which pre-computes all expansion levels but 
only reveals expanded subtrees on demand. Users click disclosure triangles to 
expand individual commands in the tree view. The session tracks expanded node 
IDs and rebuilds the visible tree dynamically, avoiding full program expansion 
until needed.

New Program Builder
-------------------
Creation: Users create empty programs via "New Program" button, specifying a 
name.

Command Addition: Modal form presents command types (dropdown), validates fields 
(variables must match x\d+|y|z\d+, labels must be L\d+|EXIT), and adds valid 
commands to the program.

XML Export: Programs export to XML format via "Export Program" button, 
preserving command structure and labels for sharing/version control.

================================================================================
HOW TO RUN
================================================================================

The submission includes:
1. source/ folder containing the application and an inner run.bat
2. run.bat (outer) at the root level
3. readme.txt (this file)

IMPORTANT - Path Requirements:
JavaFX requires that the application path contains only ASCII characters. 
Paths with Hebrew characters or special Unicode characters will cause the 
application to fail during resource loading (FXML files, CSS, etc.). This was 
not an issue in the previous console-based assignment.

Running the Application:

Option 1 (Recommended):
  Simply run the outer run.bat from the submission root. It automatically copies 
  the source folder to C:\Temp\TomBraudoEx2 (a path guaranteed to be free of 
  special characters), navigates to that directory, and executes the inner 
  run.bat.

Option 2 (If path is already safe):
  If the submission folder is already in a path without Hebrew or special 
  characters, you may directly navigate into the source\ folder and run the 
  inner run.bat from there.

Option 3 (Manual):
  If you prefer, manually copy the source folder to any location with an 
  ASCII-only path and run the inner run.bat from there.

Note for graders: The outer run.bat handles path sanitization automatically, 
so you can run it directly without checking the current path.

================================================================================

Author: Tom Braudo (324182914) | tombr2@mta.ac.il
Java Version: 21